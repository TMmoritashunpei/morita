package techma.repository.topPage;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import techma.domain.items.Item;

public interface TopPageRepository extends JpaRepository<Item, Integer> {
	
    @Query("SELECT x FROM Item x ORDER BY x.date DESC")
    List<Item> findAllOrderByName();

//    @Query("SELECT x FROM Item x ORDER BY x.firstName, x.lastName")
//    Page<Item> findAllOrderByName(Pageable pageable);

}
