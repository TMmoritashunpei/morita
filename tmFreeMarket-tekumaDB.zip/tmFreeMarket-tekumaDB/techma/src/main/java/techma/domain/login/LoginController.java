package techma.domain.login;

public class LoginController {
//@Controller
}
