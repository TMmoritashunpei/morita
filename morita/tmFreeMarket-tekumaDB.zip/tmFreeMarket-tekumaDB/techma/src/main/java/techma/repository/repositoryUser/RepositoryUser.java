package techma.repository.repositoryUser;

import org.springframework.data.jpa.repository.JpaRepository;

import techma.domain.users.User;

public interface RepositoryUser extends JpaRepository<User, String> {

}
