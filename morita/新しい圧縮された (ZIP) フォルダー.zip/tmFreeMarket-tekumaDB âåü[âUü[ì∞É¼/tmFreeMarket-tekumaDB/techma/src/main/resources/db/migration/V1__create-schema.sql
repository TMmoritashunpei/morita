CREATE TABLE items(
  id int(10) NOT NULL auto_increment,
  name VARCHAR(20) NOT NULL,
  user_id int(10) NOT NULL,
  category_id int(10) NOT NULL,
  picture_main text NOT NULL,
  picture_sub1 text,
  picture_sub2 text,
  picture_sub3 text,
  display_flg TINYINT(1) NOT NULL,
  payment VARCHAR(255) NOT NULL,
  item_condition VARCHAR(255) NOT NULL,
  price int(10) NOT NULL,
  comments text NOT NULL,
  purchase_status TINYINT(1) NOT NULL,
  date date NOT NULL,
  PRIMARY KEY(id)
);

CREATE TABLE users(
  id int(10) NOT NULL auto_increment,
  name VARCHAR(20) NOT NULL,
  mail VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  login_check TINYINT(1) NOT NULL,
  admin_flg TINYINT(1) NOT NULL,
  employee_id int(10),
  item_id int(10),
  PRIMARY KEY(id)
);

CREATE TABLE categories(
  id int(10) NOT NULL auto_increment,
  name VARCHAR(20) NOT NULL,
  PRIMARY KEY(id)
);
