package techma.domain.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import techma.domain.users.User;
import techma.repository.repositoryUser.RepositoryUser;


@Service

public class LoginUserDetailsService implements UserDetailsService{
	@Autowired
	RepositoryUser repositoryUser;
	
	@Override
	public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
		if (name == null || "".equals(name)) {
			 System.out.println(name+"ユーザーはいません");
		      throw new UsernameNotFoundException("Username is empty");		     
		}
		User user = repositoryUser.getOne(name);
		if (user == null) {
			throw new UsernameNotFoundException("\"User not found for name: \" + name");
		}
		return new LoginUserDetails(user);
	}
	
}
