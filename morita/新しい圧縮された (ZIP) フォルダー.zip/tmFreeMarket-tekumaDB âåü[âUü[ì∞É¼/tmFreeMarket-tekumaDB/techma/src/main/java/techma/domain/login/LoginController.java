package techma.domain.login;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {
	@RequestMapping(value= {"/item/loginForm"})
	String loginForm() {
		return "loginForm";
	}
	@RequestMapping("/item/exhibit")
	String exhibitlogin() {
		return "loginForm";
	}
	@RequestMapping("/item")
	String item() {
		return "item";
	}
	//@GetMapping(path = "loginForm")
	//String exhibitlogin() {
		//return "loginForm";
	//}
	
}
