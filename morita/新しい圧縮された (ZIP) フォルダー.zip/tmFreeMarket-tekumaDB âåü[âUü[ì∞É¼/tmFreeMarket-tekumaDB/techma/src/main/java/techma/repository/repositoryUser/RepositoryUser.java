package techma.repository.repositoryUser;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import techma.domain.users.User;

public interface RepositoryUser extends JpaRepository<User, String> {
	
	 @Query("SELECT x FROM User x")
	    List<User> findAllUser();

}
