package techma.web;



import java.util.Date;

//import javax.validation.constraints.NotNull;
//@@@文字数制限入れる場合実装import javax.validation.constraints.Size;

import lombok.Data;
import techma.domain.categories.Category;
import techma.domain.users.User;

@Data
public class ItemForm {
	//@NotNull
	private String name;
	private User user;
	//@NotNull
	private String picture_main;
    private String picture_sub1;
    private String picture_sub2;
    private String picture_sub3;
    private boolean display_flg = true;
    //@NotNull
    private Category category;
    private Integer payment;
    //@NotNull
    private String condition;
    //@NotNull
    private Integer price;
    //＠＠＠暫定@Size(min = 1, max = 120)
    private String comments;
    //@NotNull
    //private String purchase_status;
    private Date date;
    
}
