package techma.domain.items;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;

import java.util.Date;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import techma.domain.categories.Category;
import techma.domain.users.User;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "items")
public class Item {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false)
    private String name;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="user_id")
    private User user;
    @Column(nullable = false)
    private String picture_main;
    private String picture_sub1;
    private String picture_sub2;
    private String picture_sub3;
    @Column(nullable = false)
    private boolean display_flg = true;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="category_id")
    private Category category;
    private String payment;
    private String item_condition;
    @Column(nullable = false)
    private Integer price;
    private String comments;
    private String purchase_status;
    @Column(nullable = false)
    
    private Date date;
    public void setDare(Date date){
        this.date = date;   
    }
}