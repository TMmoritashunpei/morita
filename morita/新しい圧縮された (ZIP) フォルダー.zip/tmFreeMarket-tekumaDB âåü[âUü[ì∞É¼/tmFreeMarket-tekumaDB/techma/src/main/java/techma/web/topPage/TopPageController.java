package techma.web.topPage;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import techma.domain.categories.Category;
import techma.domain.items.Item;
import techma.service.topPage.TopPageService;
import techma.web.ItemForm;

@Controller
@RequestMapping("item")
public class TopPageController {
    @Autowired
    TopPageService topPageService;

    @GetMapping
    String list(Model model) {
        List<Item> items = topPageService.findAll();
        model.addAttribute("items", items);
        
        //About Category
        List<Category> categories = topPageService.findAllGetCategory();
        model.addAttribute("categories", categories);
        return "top/toppage";
    }
    
//    //Keyword Search
//    @GetMapping(value="/search")
//    //@RequestMapping(value="/search" )
//    public ModelAndView search(@RequestParam("keyword") String keyword){
//        ModelAndView mv = new ModelAndView();
//    	//mv.setViewName("/item");
//        if(keyword ==""){
//        	mv =new ModelAndView("top/toppage.html");
//        }else{
//            List<Item> results = topPageService.search(keyword);
//            mv.addObject("value",results);
//            mv.setViewName("top/toppage.html");
//        }
//    return mv;
//    }
    
    //Category Search
    @GetMapping(value="/search")
    public ModelAndView searchCategory(@RequestParam("search") int keyword){
        ModelAndView mv = new ModelAndView();
    	//mv.setViewName("/item");
       List<Item> results = topPageService.searchCategory(keyword);
       mv.addObject("value",results);
       mv.setViewName("top/toppage.html");
    return mv;
    }
    
    
    
    @GetMapping(value="/syuppin")
    public ModelAndView a(){
    	ModelAndView mv = new ModelAndView();
    	mv =new ModelAndView("syuppin");
    	return mv;
    }


}
