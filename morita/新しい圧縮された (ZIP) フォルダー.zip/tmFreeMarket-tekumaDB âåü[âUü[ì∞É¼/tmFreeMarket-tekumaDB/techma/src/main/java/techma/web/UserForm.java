package techma.web;

import lombok.Data;

@Data
public class UserForm {
	//@NotNull
	//private Integer id;
	//@NotNull
	private String name;
	//@NotNull
	private String mail;
	//@NotNull
	private String password;
	//@NotNull
	private Integer employee_id;
	//@NotNull
	private boolean login_check = true;
	//@NotNull
	private boolean admin_flg = false;;
}
