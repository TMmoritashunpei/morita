package techma.web.exhibit;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import techma.domain.categories.Category;
import techma.domain.items.Item;
//import techma.domain.login.LoginUserDetails;
import techma.domain.users.User;
import techma.service.topPage.TopPageService;
import techma.web.ItemForm;
import techma.web.UploadForm;



@Controller
@RequestMapping("item/exhibit")
public class ExhibitController {
	@Autowired
	TopPageService topPageService;
	
	
	

	private User user;
	@ModelAttribute
    ItemForm setUpForm() {
        return new ItemForm();
	}
	
	@GetMapping
    String list(Model model) {
		//About Category
	    List<Category> categories = topPageService.findAllGetCategory();
	    model.addAttribute("categories", categories);
	    
	    List<User> users = topPageService.findAllGetUser();
        model.addAttribute("users", users);
     
        
        List<Item> items = topPageService.findAll();
        model.addAttribute("items", items);
        return "shuppin";
    }   
	
	
	@PostMapping(path = "create")
	String create(@Validated ItemForm form, BindingResult result, Model model/*,
			@AuthenticationPrincipal LoginUserDetails userDatails*/) {
		if (result.hasErrors()) {
			return "redirect:";
		}
		
		Item item = new Item();
		Date date = new Date();
		item.setUser(user);
		item.setDate(date);
		BeanUtils.copyProperties(form, item);
		topPageService.create(item,user,/*userDatails.getUser(),*/date);
		return "redirect:../";
	}
	
	@GetMapping(path = "create" , params ="goToTop")
	String goToTop() {
		return "redirect:item";
	}
	
	@RequestMapping(path = "/sample/upload", method = RequestMethod.GET)
	String uploadview(Model model) {
	  return "sample/upload";
	}

	@RequestMapping(path = "/sample/upload", method = RequestMethod.POST)
	String upload(Model model, UploadForm uploadForm) {
	  if (uploadForm.getFile().isEmpty()) {
	    return "sample/upload";
	  }

	  // check upload distination directory.If there was no directory, make
	  // func.
	  Path path = Paths.get("/teckma/image");
	  if (!Files.exists(path)) {
	    try {
	      Files.createDirectory(path);
	    } catch (NoSuchFileException ex) {
	      System.err.println(ex);
	    } catch (IOException ex) {
	      System.err.println(ex);
	    }
	  }

	  int dot = uploadForm.getFile().getOriginalFilename().lastIndexOf(".");
	  String extention = "";
	  if (dot > 0) {
	    extention = uploadForm.getFile().getOriginalFilename().substring(dot).toLowerCase();
	  }
	  String filename = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS").format(LocalDateTime.now());
	  Path uploadfile = Paths
	      .get("/teckma/image" + filename + extention);

	  try (OutputStream os = Files.newOutputStream(uploadfile, StandardOpenOption.CREATE)) {
	    byte[] bytes = uploadForm.getFile().getBytes();
	    os.write(bytes);
	  } catch (IOException ex) {
	    System.err.println(ex);
	  }

	  return "redirect:/item/exhibit";
	}

}
	

