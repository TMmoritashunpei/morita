package techma.web.exhibit;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import techma.domain.items.Item;
import techma.service.topPage.TopPageService;
import techma.web.ItemForm;



@Controller
@RequestMapping("items/exhibit")
public class ExhibitController {
	@Autowired
	TopPageService topPageService;
	
	@GetMapping
    String list(Model model) {
        List<Item> items = topPageService.findAll();
        model.addAttribute("items", items);
        return "/shuppin";
    }   
	
	@PostMapping(path = "create")
	String create(@Validated ItemForm form, BindingResult result, Model model) {
		if (result.hasErrors()) {
		//@@@遷移先決定後パス指定
		return "exhibit";
	}
		Item item = new Item();
		BeanUtils.copyProperties(form, item);
		topPageService.create(item);
		//@@@遷移先決定後パス指定
		return "items";
	}


}
	

