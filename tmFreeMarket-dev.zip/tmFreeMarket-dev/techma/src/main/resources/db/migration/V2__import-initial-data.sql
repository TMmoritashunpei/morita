INSERT INTO items (name, user_id, category_id, picture_main, picture_sub1,
                    picture_sub2, picture_sub3, display_flg,payment, item_condition,
                    price, comments, purchase_status, date)
VALUES('test1', 1, 1, '/var/lib/mysql/image/test.jpg','','','', 1, 'credit', 'good',
        0, 'test', 0, '2018-10-10');
INSERT INTO items (name, user_id, category_id, picture_main, picture_sub1,
                    picture_sub2, picture_sub3, display_flg,payment, item_condition,
                    price, comments, purchase_status, date)
VALUES('test2', 1, 1, '/var/lib/mysql/image/test.jpg','','','', 1, 'credit', 'good',
        0, 'test', 0, '2018-10-10');
INSERT INTO items (name, user_id, category_id, picture_main, picture_sub1,
                    picture_sub2, picture_sub3, display_flg,payment, item_condition,
                    price, comments, purchase_status, date)
VALUES('test3', 1, 2, '/var/lib/mysql/image/test.jpg','','','', 1, 'credit', 'good',
        0, 'test', 0, '2018-10-10');                
INSERT INTO items (name, user_id, category_id, picture_main, picture_sub1,
                    picture_sub2, picture_sub3, display_flg,payment, item_condition,
                    price, comments, purchase_status, date)
VALUES('本', 1, 3, '/var/lib/mysql/image/test.jpg','','','', 1, 'credit', 'good',
        0, 'test', 0, '2018-10-10');

INSERT INTO users (name, mail, password, login_check,
                    admin_flg, employee_id, item_id)
VALUES('admin', 'test@test.com', 'test', 1, 1, 1, 1);

INSERT INTO users (name, mail, password, login_check,
                    admin_flg, employee_id, item_id)
VALUES('test', 'test@test.com', 'test', 1, 0, 1, 1);

INSERT INTO categories (name)
VALUES('test');

INSERT INTO categories (name)
VALUES('test1');

INSERT INTO categories (name)
VALUES('test2');